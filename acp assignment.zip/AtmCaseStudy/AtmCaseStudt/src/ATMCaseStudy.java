// ATMCaseSTudy.java
// Driver program for the ATM case study

public class ATMCaseStudy {
	public static void main(String[] args) {
		ATM theATM = new ATM();
		theATM.run();
	}
}
