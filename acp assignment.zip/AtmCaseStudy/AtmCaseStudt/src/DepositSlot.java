// DepositSlot.java
// Represents the deposit slot of the ATM

public class DepositSlot {
	// deposit slot always true because it is just a simulation
	public boolean isEnvelopeReceived() {
		return true;
	}
}
