import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class Main implements ActionListener {
    private JFrame frame;
    private JTextField textField;
    private JButton[] numberButtons;

    private double operand1 = 0;
    private double operand2 = 0;
    private char operator = ' ';

    public Main() {
        frame = new JFrame("Calculator");
        frame.setSize(300, 300);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        textField = new JTextField();
        textField.setHorizontalAlignment(JTextField.RIGHT);
        frame.add(textField, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(5, 4));

        String[] buttonLabels = {"7", "8", "9", "/", "4", "5", "6", "*", "1", "2", "3", "-", "0", ".", "=", "+", "tan", "cos", "C", "<--"};

        numberButtons = new JButton[buttonLabels.length];
        for (int i = 0; i < buttonLabels.length; i++) {
            numberButtons[i] = new JButton(buttonLabels[i]);
            numberButtons[i].addActionListener(this);
            buttonPanel.add(numberButtons[i]);
        }

        frame.add(buttonPanel, BorderLayout.CENTER);
        frame.setVisible(true);
    }

    public void actionPerformed(ActionEvent e) {
        JButton button = (JButton) e.getSource();
        String buttonText = button.getText();

        if (Character.isDigit(buttonText.charAt(0)) || buttonText.equals(".")) {
            textField.setText(textField.getText() + buttonText);
        } else if (buttonText.equals("=")) {
            operand2 = Double.parseDouble(textField.getText());
            double result = performOperation(operand1, operand2, operator);
            textField.setText(String.valueOf(result));
            operand1 = 0;
            operand2 = 0;
            operator = ' ';
        } else if (buttonText.equals("C")) {
            textField.setText("");
        } else if (buttonText.equals("<--")) {
            String currentText = textField.getText();
            if (currentText.length() > 0) {
                textField.setText(currentText.substring(0, currentText.length() - 1));
            }
        } else if (buttonText.equals("tan") || buttonText.equals("cos")) {
            double value = Double.parseDouble(textField.getText());
            double result = buttonText.equals("tan") ? Math.tan(Math.toRadians(value)) : Math.cos(Math.toRadians(value));
            textField.setText(String.valueOf(result));
        } else {
            operator = buttonText.charAt(0);
            operand1 = Double.parseDouble(textField.getText());
            textField.setText("");
        }
    }

    private double performOperation(double operand1, double operand2, char operator) {
        double result = 0;
        switch (operator) {
            case '+' -> result = operand1 + operand2;
            case '-' -> result = operand1 - operand2;
            case '*' -> result = operand1 * operand2;
            case '/' -> {
                if (operand2 != 0) {
                    result = operand1 / operand2;
                } else {
                    JOptionPane.showMessageDialog(frame, "Error: Division by zero");
                }
            }
        }
        return result;
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                new Main();
            }
        });
    }
}
